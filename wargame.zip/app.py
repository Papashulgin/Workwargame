from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)

with open('game_state.json', 'r') as f:
    game_state = json.load(f)

@app.route('/')
def index():
    return render_template('index.html', game=game_state)

@app.route('/turn', methods=['POST'])
def next_turn():
    game_state['turn'] += 1
    game_state['resources']['food'] += 10
    update_unit_experience()
    save_state()
    return jsonify(success=True, game=game_state)

@app.route('/buy_unit', methods=['POST'])
def buy_unit():
    unit = request.json.get('unit')
    costs = {'infantry': 10, 'drone': 30, 'abc_weapon': 100}
    if unit in costs and game_state['resources']['gold'] >= costs[unit]:
        game_state['military'][unit] = game_state['military'].get(unit, 0) + 1
        game_state['resources']['gold'] -= costs[unit]
    save_state()
    return jsonify(game=game_state)

@app.route('/battle', methods=['POST'])
def battle():
    if game_state['military'].get('infantry', 0) > 5:
        game_state['military']['infantry'] -= 5
        game_state['territory'] += 1
        result = "Victory! Territory gained."
    else:
        result = "Defeat. Not enough troops."
    save_state()
    return jsonify(result=result, game=game_state)

@app.route('/espionage', methods=['POST'])
def espionage():
    action = request.json.get('action')
    success = True if action in ['sabotage', 'steal', 'reveal'] else False
    result = f"Espionage action: {action} {'succeeded' if success else 'failed'}"
    save_state()
    return jsonify(success=success, result=result)

@app.route('/aid', methods=['POST'])
def aid():
    amount = request.json.get('amount', 0)
    if game_state['resources']['gold'] >= amount:
        game_state['resources']['gold'] -= amount
        game_state['diplomacy']['aid_given'] += amount
        result = f"Sent {amount} gold in international aid."
    else:
        result = "Not enough gold."
    save_state()
    return jsonify(result=result, game=game_state)

@app.route('/map_click', methods=['POST'])
def map_click():
    region = request.json.get('region')
    game_state['visible_regions'].append(region)
    save_state()
    return jsonify(success=True, region=region)

def update_unit_experience():
    for unit, count in game_state['military'].items():
        if unit != 'abc_weapon':
            game_state['experience'][unit] = game_state['experience'].get(unit, 0) + count

def save_state():
    with open('game_state.json', 'w') as f:
        json.dump(game_state, f, indent=4)

if __name__ == '__main__':
    app.run(debug=True)
